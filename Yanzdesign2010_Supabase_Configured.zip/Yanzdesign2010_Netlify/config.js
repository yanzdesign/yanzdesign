// Konfigurasi Supabase YanzDesign2010
// Publishable key aman digunakan pada frontend dengan RLS aktif.
// Jangan pernah menambahkan service_role/secret key di file ini.
window.YANZ_SUPABASE_CONFIG = {
  url: "https://vxzognkkpgdacmlgnlgi.supabase.co",
  anonKey: "sb_publishable_ul2i0rGPX7erC2ID8CnsiQ_DoHIc0d9"
};
