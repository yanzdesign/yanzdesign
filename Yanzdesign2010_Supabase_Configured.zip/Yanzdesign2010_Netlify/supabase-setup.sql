-- Jalankan seluruh SQL ini di Supabase > SQL Editor.
create table if not exists public.site_content (
  id integer primary key check (id = 1),
  content jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.site_content enable row level security;

-- Pengunjung boleh membaca konten website, tetapi tidak boleh mengubahnya.
drop policy if exists "Public can read site content" on public.site_content;
create policy "Public can read site content"
on public.site_content for select
using (true);

-- Hanya akun admin yang ditentukan dapat menulis.
drop policy if exists "Only Yanz admin can insert" on public.site_content;
create policy "Only Yanz admin can insert"
on public.site_content for insert to authenticated
with check ((auth.jwt() ->> 'email') = 'yanzportofolio@gmail.com');

drop policy if exists "Only Yanz admin can update" on public.site_content;
create policy "Only Yanz admin can update"
on public.site_content for update to authenticated
using ((auth.jwt() ->> 'email') = 'yanzportofolio@gmail.com')
with check ((auth.jwt() ->> 'email') = 'yanzportofolio@gmail.com');

-- Isi awal agar situs memiliki satu baris yang siap disimpan.
insert into public.site_content (id, content)
values (1, '{}'::jsonb)
on conflict (id) do nothing;
